<?php
		$link = mysqli_connect("localhost", "root", "");
		mysqli_select_db($link, "mystatus_db");  
		mysqli_query($link, "SET CHARACTER SET utf8");
		?>
		