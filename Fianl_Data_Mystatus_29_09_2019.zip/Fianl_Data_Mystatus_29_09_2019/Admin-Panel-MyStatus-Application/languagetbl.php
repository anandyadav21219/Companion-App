<?php
				include "includes/header.php";
				?>

				<a class="btn btn-primary" href="edit-languagetbl.php?act=add"> <i class="glyphicon glyphicon-plus-sign"></i> Add New Language</a>

				<h1>Language</h1>
				<p>This table includes <?php echo counting("languagetbl", "id");?> language.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Languageid</th>
					<th>Languagename</th>
					<th class="not">Edit</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$languagetbl = getAll("languagetbl");
				if($languagetbl) foreach ($languagetbl as $languagetbls):
					?>
					<tr>
						<td><?php echo $languagetbls['languageid']?></td>
						<td><?php echo $languagetbls['languagename']?></td>
						<td><a href="edit-languagetbl.php?act=edit&id=<?php echo $languagetbls['languageid']?>"><i class="glyphicon glyphicon-edit"></i></a></td>
						<td><a href="save.php?act=delete&id=<?php echo $languagetbls['languageid']?>&cat=languagetbl" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a></td>
					</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				