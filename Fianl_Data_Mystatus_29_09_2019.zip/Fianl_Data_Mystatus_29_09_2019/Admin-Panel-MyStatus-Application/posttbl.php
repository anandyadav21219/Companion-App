<?php
				include "includes/header.php";
				?>

				<a class="btn btn-primary" href="edit-posttbl.php?act=add"> <i class="glyphicon glyphicon-plus-sign"></i> Add New Post</a>

				<h1>Post</h1>
				<p>This table includes <?php echo counting("posttbl", "id");?> posts.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Postid</th>
					<th>Category</th>
					<th>Language</th>
					<th>Thumbnail Image</th>
					<th>Title</th>
					<th>Post-Path</th>
					<th>No. of Like</th>
					<th>No. of Share</th>
					<th>No. of Download</th>
					<th>No. of View</th>
					<th>Post-Date</th>
					<th class="not">Edit</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$posttbl = getPost1();
				if($posttbl) foreach ($posttbl as $posttbls):
					?>
					<tr>
						<td><?php echo $posttbls['postid']?></td>
						<td><?php echo $posttbls['categoryname']?></td>
						<td><?php echo $posttbls['languagename']?></td>
						<td><?php echo $posttbls['thumbnail_img']?></td>
						<td><?php echo $posttbls['title']?></td>
						<td><?php echo $posttbls['postpath']?></td>
						<td><?php echo $posttbls['no_of_like']?></td>
						<td><?php echo $posttbls['no_of_share']?></td>
						<td><?php echo $posttbls['no_of_download']?></td>
						<td><?php echo $posttbls['no_of_view']?></td>
						<td><?php echo $posttbls['post_date']?></td>
						<td><a href="edit-posttbl.php?act=edit&id=<?php echo $posttbls['postid']?>"><i class="glyphicon glyphicon-edit"></i></a></td>
						<td><a href="save.php?act=delete&id=<?php echo $posttbls['postid']?>&cat=posttbl" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a></td>
						</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				